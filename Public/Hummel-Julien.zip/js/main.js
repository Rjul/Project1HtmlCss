/// ---------------- Main .js ----------------///

///  Gestion header ( link home )
// init variable 
document.getElementById('title').addEventListener('click', () => {
    window.location = '../Public/index.php'
})