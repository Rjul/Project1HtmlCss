<?php include './elms-pages/head_bo.php' ?>
<?php include './elms-pages/base_bo.php' ?>
<canvas id="transformationVente"></canvas>
<canvas id="chiffreAffaire"></canvas>
<script src="./js/graphique.js"></script>
<?php include './elms-pages/footer_bo.php' ?>

<style>
    * {
        overflow-y: hidden;
        overflow-x: hidden;
    }

    #app {
        height: 95vh;

    }
</style>