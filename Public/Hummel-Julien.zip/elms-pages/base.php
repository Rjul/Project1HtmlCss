<body>
    <div id='container'>
        <header>
            <a href="./index.php" class="magical-link">
                <div class="string c-right"></div>
                <div class="string c-left"></div>
                <h1 id='title'>Super Montre</h1>
            </a>
            <span id='authButton'>Connection / Inscription</span>
        </header>
        <div id="hero-container">
            <div id='hero'>
                <!-- <img src="./asset/hero.png" alt=""> -->
            </div>
        </div>
        <section>