<body>
    <div id='app'>
        <header id="menu">
            <nav>
                <a href="./dashboard.php">
                    <div class="btnNav">Dashboard</div>
                </a>
                <a href="./produit-bo.php">
                    <div class="btnNav">Produits</div>
                </a>
                <a href="./command-bo.php">
                    <div class="btnNav">Commandes</div>
                </a>
                <a href="./user-bo.php">
                    <div class="btnNav">Clients</div>
                </a>
                <a href="./index.php">
                    <div class="btnNav">S-Montre</div>
                </a>
            </nav>
        </header>

        <button id='btnMenu'>
            <img class='btnMenu' src="./asset/icon-menu.png" alt="">
        </button>
        <div id='container'>