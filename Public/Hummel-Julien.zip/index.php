<?php
include './elms-pages/head.php';
include './elms-pages/base.php';
?>
<link rel="stylesheet" media="all and (min-width: 800px)" href="./css/index/listProduit.css">
<link rel="stylesheet" media="all and (max-width: 800px) and (min-width: 600px)" href="./css//index/list-produit-tab.css">
<link rel="stylesheet" media="all and (max-width: 600px)" href="./css/index/list-produit-phone.css">
<div class='ficheList'>
    <a href="./fiche-produit.php">
        <img src="./asset/Montre 1.webp" alt="" />
        <span>Super Grolex</span>
        <div>
            <span class='description'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam,
                maiores?</span>
            <span>8000$</span>
        </div>
    </a>
</div>

<div class='ficheList'>
    <a href="./fiche-produit.php">
        <img src="./asset/Montre_2.webp" alt="" />
        <span>Magnifique Cadran</span>
        <div>
            <span class='description'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam,
                maiores?</span>
            <span>8000$</span>
        </div>
    </a>
</div>

<div class='ficheList'>
    <a href="./fiche-produit.php">
        <img src="./asset/Montre_3.webp" alt="" />
        <span>Super montre en or !</span>
        <div>
            <span class='description'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam,
                maiores?</span>
            <span>8000$</span>
        </div>
    </a>
</div>

<div class='ficheList'>
    <a href="./fiche-produit.php">
        <img src="./asset/Montre_4.webp" alt="" />
        <span>Super montre en or !</span>
        <div>
            <span class='description'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam,
                maiores?</span>
            <span>8000$</span>
        </div>
    </a>
</div>

<div class='ficheList'>
    <a href="./fiche-produit.php">
        <img src="./asset/Montre_5.jpg" alt="" />
        <span>Super montre en or !</span>
        <div>
            <span class='description'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam,
                maiores?</span>
            <span>8000$</span>
        </div>
    </a>
</div>

<div class='ficheList'>
    <a href="./fiche-produit.php">
        <img src="./asset/Montre_6.webp" alt="" />

        <span>Super montre en or !</span>
        <div>
            <span class='description'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam,
                maiores?</span>
            <span>8000$</span>
        </div>
    </a>
</div>
<div class='ficheList'>
    <a href="./fiche-produit.php">
        <img src="./asset/Montre 1.webp" alt="" />
        <span>Super Grolex</span>
        <div>
            <span class='description'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam,
                maiores?</span>
            <span>8000$</span>
        </div>
    </a>
</div>

<div class='ficheList'>
    <a href="./fiche-produit.php">
        <img src="./asset/Montre_2.webp" alt="" />
        <span>Magnifique Cadran</span>
        <div>
            <span class='description'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam,
                maiores?</span>
            <span>8000$</span>
        </div>
    </a>
</div>

<div class='ficheList'>
    <a href="./fiche-produit.php">
        <img src="./asset/Montre_3.webp" alt="" />
        <span>Super montre en or !</span>
        <div>
            <span class='description'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam,
                maiores?</span>
            <span>8000$</span>
        </div>
    </a>
</div>

<div class='ficheList'>
    <a href="./fiche-produit.php">
        <img src="./asset/Montre_4.webp" alt="" />
        <span>Super montre en or !</span>
        <div>
            <span class='description'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam,
                maiores?</span>
            <span>8000$</span>
        </div>
    </a>
</div>

<div class='ficheList'>
    <a href="./fiche-produit.php">
        <img src="./asset/Montre_5.jpg" alt="" />
        <span>Super montre en or !</span>
        <div>
            <span class='description'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam,
                maiores?</span>
            <span>8000$</span>
        </div>
    </a>
</div>

<div class='ficheList'>
    <a href="./fiche-produit.php">
        <img src="./asset/Montre_6.webp" alt="" />
        <span>Super montre en or !</span>
        <div>
            <span class='description'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam,
                maiores?</span>
            <span>8000$</span>
        </div>
    </a>
</div>
<script src="./js/listProduit.js"></script>
<?php include './elms-pages/footer.php' ?>