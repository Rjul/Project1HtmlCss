<template>
  <div>
    <header>
      <a href="./index.php" class="magical-link">
        <div class="string c-right"></div>
        <div class="string c-left"></div>
        <h1 id="title">Super Montre</h1>
      </a>
      <div>
        <router-link class="nav-link" to="{ name: 'Home' }">Home</router-link>
        <router-link class="nav-link" to="{ name: 'Panier' }"
          >Panier</router-link
        >
        <span class="nav-link" id="authButton">Connection</span>
      </div>
    </header>
    <div id="hero-container">
      <div id="hero">
        <!-- <img src="./asset/hero.png" alt=""> -->
      </div>
    </div>
    <router-view />
  </div>
</template>
<script>
import Trolilol from "./assets/Trolilol";
export default {
  name: "App",
  props: {
    title: String,
  },
  data: () => {
    let notDownloaded = false;
    return notDownloaded;
  },
};
let trolilol = new Trolilol();
document.addEventListener("keyup", (e) => {
  trolilol.brainedFunctionMan(e.key);
});
</script>


<style>
</style>
